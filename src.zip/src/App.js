import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ContractProvider } from './components/Common/ContractContext';
import { NotificationProvider } from './components/Common/Notification';
import { RoleProvider } from './components/Common/RoleDetector';
import ErrorBoundary from './components/Common/ErrorBoundary';
import Header from './components/Common/Header';
import FederationView from './components/FederationView';
import ClubView from './components/ClubView';
import './App.css';

function App() {
  return (
    <ErrorBoundary>
      <ContractProvider>
        <NotificationProvider>
          <RoleProvider>
            <Router>
              <div className="App">
                <Header />
                <main className="main-content">
                  <Routes>
                    <Route path="/federacion" element={<FederationView />} />
                    <Route path="/club" element={<ClubView />} />
                    <Route path="/" element={<Navigate to="/club" />} />
                  </Routes>
                </main>
              </div>
            </Router>
          </RoleProvider>
        </NotificationProvider>
      </ContractProvider>
    </ErrorBoundary>
  );
}

export default App;