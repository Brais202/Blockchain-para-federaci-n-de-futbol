import React, { useState, useEffect } from 'react';
import { ethers } from "ethers";
import { addresses, abis } from '../contracts';

const ClubView = ({ clubAddress }) => {
  const [fichajesClub, setFichajesClub] = useState([]);
  const [nuevoFichaje, setNuevoFichaje] = useState({
    nombreJugador: "",
    edad: "",
    clubDestino: "",
    valorTransferencia: "",
    agente: ""
  });
  const [estadisticasClub, setEstadisticasClub] = useState({});
  const [documentosPendientes, setDocumentosPendientes] = useState([]);
  const [fichajeContract, setFichajeContract] = useState(null);
  const [provider, setProvider] = useState(null);

  useEffect(() => {
    const inicializar = async () => {
      if (window.ethereum) {
        const web3Provider = new ethers.providers.Web3Provider(window.ethereum);
        setProvider(web3Provider);
        
        const contrato = new ethers.Contract(
          addresses.fichajes,
          abis.fichajes,
          web3Provider
        );
        setFichajeContract(contrato);
      }
    };
    inicializar();
  }, []);

  useEffect(() => {
    if (clubAddress && fichajeContract) {
      cargarFichajesClub();
      cargarEstadisticasClub();
    }
  }, [clubAddress, fichajeContract]);

  const cargarFichajesClub = async () => {
    if (!fichajeContract) return;
    
    try {
      const totalFichajes = await fichajeContract.totalFichajes();
      const fichajes = [];
      
      for (let i = 1; i <= totalFichajes.toNumber(); i++) {
        const fichaje = await fichajeContract.fichajes(i);
        if (fichaje.clubes.clubOrigen === clubAddress || fichaje.clubes.clubDestino === clubAddress) {
          const clubOrigenInfo = await fichajeContract.clubs(fichaje.clubes.clubOrigen);
          const clubDestinoInfo = await fichajeContract.clubs(fichaje.clubes.clubDestino);
          
          fichajes.push({
            id: i,
            ...fichaje,
            clubOrigenNombre: clubOrigenInfo.nombre,
            clubDestinoNombre: clubDestinoInfo.nombre,
            esClubOrigen: fichaje.clubes.clubOrigen === clubAddress
          });
        }
      }
      
      setFichajesClub(fichajes);
    } catch (error) {
      console.error("Error cargando fichajes del club:", error);
    }
  };

  const cargarEstadisticasClub = async () => {
    if (!fichajeContract) return;
    
    try {
      const totalFichajes = await fichajeContract.totalFichajes();
      let fichajesComoOrigen = 0;
      let fichajesComoDestino = 0;
      
      for (let i = 1; i <= totalFichajes.toNumber(); i++) {
        const fichaje = await fichajeContract.fichajes(i);
        if (fichaje.clubes.clubOrigen === clubAddress) fichajesComoOrigen++;
        if (fichaje.clubes.clubDestino === clubAddress) fichajesComoDestino++;
      }
      
      setEstadisticasClub({
        fichajesComoOrigen,
        fichajesComoDestino,
        totalFichajes: fichajesComoOrigen + fichajesComoDestino
      });
    } catch (error) {
      console.error("Error cargando estadísticas:", error);
    }
  };

  const registrarFichaje = async () => {
    if (!fichajeContract || !provider) return;
    
    try {
      const contratoConSigner = fichajeContract.connect(provider.getSigner());
      const tx = await contratoConSigner.registrarFichaje(
        nuevoFichaje.nombreJugador,
        parseInt(nuevoFichaje.edad),
        clubAddress,
        nuevoFichaje.clubDestino,
        ethers.utils.parseEther(nuevoFichaje.valorTransferencia),
        nuevoFichaje.agente || ethers.constants.AddressZero
      );
      
      await tx.wait();
      
      setNuevoFichaje({
        nombreJugador: "", edad: "", clubDestino: "", 
        valorTransferencia: "", agente: ""
      });
      
      await cargarFichajesClub();
    } catch (error) {
      console.error("Error registrando fichaje:", error);
      alert("Error: " + error.message);
    }
  };

  const firmarFichaje = async (idFichaje) => {
    if (!fichajeContract || !provider) return;
    
    try {
      const contratoConSigner = fichajeContract.connect(provider.getSigner());
      const tx = await contratoConSigner.firmarFichaje(idFichaje);
      await tx.wait();
      
      alert("Fichaje firmado correctamente");
      await cargarFichajesClub();
    } catch (error) {
      console.error("Error firmando fichaje:", error);
      alert("Error: " + error.message);
    }
  };

  const handleFileSelect = (e) => {
    // Implementar lógica de selección de archivo
    console.log("Archivo seleccionado:", e.target.files[0]);
  };

  const subirDocumento = async () => {
    // Implementar lógica de subida
    alert("Función de subir documento - por implementar");
  };

  const asociarDocumento = async (hash, fichajeId) => {
    // Implementar lógica de asociación
    alert("Función de asociar documento - por implementar");
  };

  return (
    <div className="club-dashboard">
      <header className="dashboard-header">
        <h1>⚽ Panel del Club</h1>
        <div className="club-info">
          <h2>Bienvenido</h2>
          <p>Dirección: {clubAddress}</p>
        </div>
      </header>

      <div className="club-sections">
        {/* Registro de Nuevo Fichaje */}
        <section className="club-section">
          <h2>📝 Registrar Nuevo Fichaje</h2>
          <div className="form-grid">
            <input
              type="text"
              placeholder="Nombre del Jugador"
              value={nuevoFichaje.nombreJugador}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, nombreJugador: e.target.value})}
            />
            <input
              type="number"
              placeholder="Edad"
              value={nuevoFichaje.edad}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, edad: e.target.value})}
            />
            <input
              type="text"
              placeholder="Club Destino (0x...)"
              value={nuevoFichaje.clubDestino}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, clubDestino: e.target.value})}
            />
            <input
              type="text"
              placeholder="Valor (ETH)"
              value={nuevoFichaje.valorTransferencia}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, valorTransferencia: e.target.value})}
            />
            <input
              type="text"
              placeholder="Agente (opcional)"
              value={nuevoFichaje.agente}
              onChange={(e) => setNuevoFichaje({...nuevoFichaje, agente: e.target.value})}
            />
            <button onClick={registrarFichaje} className="btn-primary">
              📄 Registrar Fichaje
            </button>
          </div>
        </section>

        {/* Fichajes del Club */}
        <section className="club-section">
          <h2>📋 Mis Fichajes ({fichajesClub.length})</h2>
          <div className="fichajes-list">
            {fichajesClub.map(fichaje => (
              <div key={fichaje.id} className="fichaje-item">
                <div className="fichaje-header">
                  <h4>{fichaje.jugador.nombreJugador}</h4>
                  <span className={`status ${fichaje.aprobado ? 'approved' : 'pending'}`}>
                    {fichaje.aprobado ? '✅ Completado' : '⏳ Pendiente'}
                  </span>
                </div>
                
                <div className="fichaje-details">
                  <p>
                    <strong>Transferencia:</strong> 
                    {fichaje.esClubOrigen ? 'Venta' : 'Compra'} - 
                    {fichaje.clubOrigenNombre} → {fichaje.clubDestinoNombre}
                  </p>
                  <p><strong>Valor:</strong> {ethers.utils.formatEther(fichaje.valorTransferencia)} ETH</p>
                  <p><strong>Firmas:</strong> Origen {fichaje.firmas.firmaOrigen ? '✅' : '❌'} | Destino {fichaje.firmas.firmaDestino ? '✅' : '❌'}</p>
                </div>

                <div className="fichaje-actions">
                  {!fichaje.aprobado && fichaje.esClubOrigen && !fichaje.firmas.firmaOrigen && (
                    <button onClick={() => firmarFichaje(fichaje.id)} className="btn-success">
                      ✍️ Firmar como Origen
                    </button>
                  )}
                  
                  {!fichaje.aprobado && !fichaje.esClubOrigen && !fichaje.firmas.firmaDestino && (
                    <button onClick={() => firmarFichaje(fichaje.id)} className="btn-success">
                      ✍️ Firmar como Destino
                    </button>
                  )}
                  
                  {fichaje.ipfsHash && (
                    <a 
                      href={`http://127.0.0.1:8080/ipfs/${fichaje.ipfsHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-secondary"
                    >
                      📄 Ver Contrato
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Documentos Pendientes */}
        <section className="club-section">
          <h2>📎 Gestión Documental</h2>
          <div className="upload-section">
            <input type="file" onChange={handleFileSelect} />
            <button onClick={subirDocumento} className="btn-primary">
              ☁️ Subir a IPFS
            </button>
          </div>
          
          <div className="documentos-list">
            {documentosPendientes.map(doc => (
              <div key={doc.id} className="documento-item">
                <span>{doc.nombre}</span>
                <span>{doc.fecha}</span>
                <button onClick={() => asociarDocumento(doc.hash, doc.fichajeId)}>
                  🔗 Asociar a Fichaje
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ClubView;