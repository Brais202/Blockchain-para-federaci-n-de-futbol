import React, { useState, useEffect } from 'react';
import { ethers } from "ethers";
import { addresses, abis } from '../contracts';

const FederationView = () => {
  const [clubs, setClubs] = useState([]);
  const [nuevoClub, setNuevoClub] = useState({ direccion: "", nombre: "" });
  const [estadisticas, setEstadisticas] = useState({});
  const [fichajesPendientes, setFichajesPendientes] = useState([]);
  const [fichajeContract, setFichajeContract] = useState(null);
  const [provider, setProvider] = useState(null);

  useEffect(() => {
    const inicializar = async () => {
      if (window.ethereum) {
        const web3Provider = new ethers.providers.Web3Provider(window.ethereum);
        setProvider(web3Provider);
        
        const contrato = new ethers.Contract(
          addresses.fichajes,
          abis.fichajes,
          web3Provider
        );
        setFichajeContract(contrato);
      }
    };
    inicializar();
  }, []);

  useEffect(() => {
    if (fichajeContract) {
      cargarClubsAutorizados();
      cargarEstadisticas();
      cargarFichajesPendientes();
    }
  }, [fichajeContract]);

  const cargarClubsAutorizados = async () => {
    if (!fichajeContract) return;
    
    try {
      const totalClubs = await fichajeContract.clubsRegistradosLength();
      const clubsArray = [];
      
      for (let i = 0; i < totalClubs.toNumber(); i++) {
        const direccionClub = await fichajeContract.clubsRegistrados(i);
        const clubInfo = await fichajeContract.clubs(direccionClub);
        
        clubsArray.push({
          direccion: direccionClub,
          nombre: clubInfo.nombre,
          autorizado: clubInfo.autorizado,
          fechaRegistro: new Date(clubInfo.fechaRegistro.toNumber() * 1000)
        });
      }
      
      setClubs(clubsArray);
    } catch (error) {
      console.error("Error cargando clubs:", error);
    }
  };

  const cargarEstadisticas = async () => {
    if (!fichajeContract) return;
    
    try {
      const totalFichajes = await fichajeContract.totalFichajes();
      const totalClubs = await fichajeContract.clubsRegistradosLength();
      
      setEstadisticas({
        totalFichajes: totalFichajes.toNumber(),
        totalClubs: totalClubs.toNumber(),
        fondosEnEscrow: "0 ETH",
      });
    } catch (error) {
      console.error("Error cargando estadísticas:", error);
    }
  };

  const cargarFichajesPendientes = async () => {
    if (!fichajeContract) return;
    
    try {
      const totalFichajes = await fichajeContract.totalFichajes();
      const pendientes = [];
      
      for (let i = 1; i <= totalFichajes.toNumber(); i++) {
        const fichaje = await fichajeContract.fichajes(i);
        if (!fichaje.aprobado) {
          const clubOrigenInfo = await fichajeContract.clubs(fichaje.clubes.clubOrigen);
          const clubDestinoInfo = await fichajeContract.clubs(fichaje.clubes.clubDestino);
          
          pendientes.push({
            id: i,
            jugador: fichaje.jugador.nombreJugador,
            origen: clubOrigenInfo.nombre,
            destino: clubDestinoInfo.nombre,
            valor: ethers.utils.formatEther(fichaje.valorTransferencia)
          });
        }
      }
      
      setFichajesPendientes(pendientes);
    } catch (error) {
      console.error("Error cargando fichajes pendientes:", error);
    }
  };

  const autorizarClub = async (direccion, nombre) => {
    if (!fichajeContract || !provider) return;
    
    try {
      const contratoConSigner = fichajeContract.connect(provider.getSigner());
      const tx = await contratoConSigner.autorizarClub(direccion, nombre);
      await tx.wait();
      
      alert("Club autorizado correctamente");
      await cargarClubsAutorizados();
    } catch (error) {
      console.error("Error autorizando club:", error);
      alert("Error: " + error.message);
    }
  };

  const desautorizarClub = async (direccionClub) => {
    if (!fichajeContract || !provider) return;
    
    try {
      const contratoConSigner = fichajeContract.connect(provider.getSigner());
      const tx = await contratoConSigner.desautorizarClub(direccionClub);
      await tx.wait();
      
      alert("Club desautorizado correctamente");
      await cargarClubsAutorizados();
    } catch (error) {
      console.error("Error desautorizando club:", error);
      alert("Error: " + error.message);
    }
  };

  const calcularComisionesPeriodo = async () => {
    // Implementar cálculo de comisiones
    return {
      total: "0 ETH",
      detalle: []
    };
  };

  const generarReporteComisiones = async () => {
    const comisiones = await calcularComisionesPeriodo();
    alert(`Reporte de comisiones: ${comisiones.total}`);
  };

  const generarReporteFichajes = async () => {
    alert("Generando reporte de fichajes...");
  };

  const auditarTransacciones = async () => {
    alert("Iniciando auditoría de transacciones...");
  };

  return (
    <div className="federation-dashboard">
      <header className="dashboard-header">
        <h1>🏛️ Panel de Control - Federación Española de Fútbol</h1>
        <div className="stats-grid">
          <div className="stat-card">
            <h3>Clubs Autorizados</h3>
            <p className="stat-number">{estadisticas.totalClubs}</p>
          </div>
          <div className="stat-card">
            <h3>Fichajes Totales</h3>
            <p className="stat-number">{estadisticas.totalFichajes}</p>
          </div>
          <div className="stat-card">
            <h3>Fondos en Escrow</h3>
            <p className="stat-number">{estadisticas.fondosEnEscrow}</p>
          </div>
        </div>
      </header>

      <div className="admin-sections">
        {/* Gestión de Clubs */}
        <section className="admin-section">
          <h2>👥 Gestión de Clubs</h2>
          <div className="form-grid">
            <input
              type="text"
              placeholder="Dirección Ethereum del club"
              value={nuevoClub.direccion}
              onChange={(e) => setNuevoClub({...nuevoClub, direccion: e.target.value})}
            />
            <input
              type="text"
              placeholder="Nombre oficial del club"
              value={nuevoClub.nombre}
              onChange={(e) => setNuevoClub({...nuevoClub, nombre: e.target.value})}
            />
            <button onClick={() => autorizarClub(nuevoClub.direccion, nuevoClub.nombre)} className="btn-primary">
              ✅ Autorizar Club
            </button>
          </div>

          <div className="clubs-list">
            <h3>Clubs Registrados</h3>
            {clubs.map(club => (
              <div key={club.direccion} className="club-item">
                <span className="club-name">{club.nombre}</span>
                <span className="club-address">{club.direccion}</span>
                <span className={`status ${club.autorizado ? 'authorized' : 'unauthorized'}`}>
                  {club.autorizado ? '✅ Autorizado' : '❌ No autorizado'}
                </span>
                {club.autorizado && (
                  <button 
                    onClick={() => desautorizarClub(club.direccion)}
                    className="btn-danger"
                  >
                    Revocar Autorización
                  </button>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Auditoría y Reportes */}
        <section className="admin-section">
          <h2>📊 Auditoría y Reportes</h2>
          <div className="report-actions">
            <button onClick={generarReporteComisiones} className="btn-info">
              📈 Reporte de Comisiones
            </button>
            <button onClick={generarReporteFichajes} className="btn-info">
              📋 Reporte de Fichajes
            </button>
            <button onClick={auditarTransacciones} className="btn-info">
              🔍 Auditoría de Transacciones
            </button>
          </div>
        </section>

        {/* Fichajes Pendientes de Revisión */}
        <section className="admin-section">
          <h2>⏳ Fichajes Pendientes</h2>
          <div className="pending-transfers">
            {fichajesPendientes.map(fichaje => (
              <div key={fichaje.id} className="pending-item">
                <div className="transfer-info">
                  <strong>{fichaje.jugador}</strong>
                  <span>{fichaje.origen} → {fichaje.destino}</span>
                  <span>{fichaje.valor} ETH</span>
                </div>
                <div className="transfer-actions">
                  <button className="btn-success">✅ Aprobar</button>
                  <button className="btn-warning">📋 Revisar Documentos</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default FederationView;