const addresses = {
  fichajes: "0xCf229762B6A806DAd28578F65B04faF8B4a211ab", 
};

export default addresses;
